# CIFAR-10 class names
class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

# Function to preprocess the image
def preprocess_image(image_data):
    image = Image.open(io.BytesIO(image_data)).resize((32, 32))
    image = np.array(image) / 255.0  # Normalize pixel values
    image = image.reshape((1, 32, 32, 3))  # Reshape to match model's input shape
    return image

# Function to perform prediction
def predict_image(image_data):
    image = preprocess_image(image_data)
    prediction = model.predict(image)
    predicted_class = np.argmax(prediction)
    return class_names[predicted_class]

# Function to handle file upload and display prediction (for web interface)
def handle_upload():
    uploaded = files.upload()
    for file_name, file_data in uploaded.items():
        print("Uploaded file:", file_name)
        image = Image.open(io.BytesIO(file_data))
        plt.imshow(image)
        plt.title("Uploaded Image")
        plt.show()
        predicted_class = predict_image(file_data)
        print("Predicted Class:", predicted_class)

# Call the function to handle upload and prediction
handle_upload()
