import tensorflow as tf
from tensorflow.keras.models import load_model
import numpy as np
from PIL import Image
import io
import base64
from IPython.display import display, HTML, Javascript

# CIFAR-10 class names
class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

# Load the trained model
model = load_model('cnn_cifar10_model.h5')

# Function to preprocess the image
def preprocess_image(image_data):
    image = Image.open(io.BytesIO(image_data)).resize((32, 32))
    image = np.array(image) / 255.0  # Normalize pixel values
    image = image.reshape((1, 32, 32, 3))  # Reshape to match model's input shape
    return image

# Define the predict function
def predict_image(image_tensor):
    prediction = model(image_tensor)
    predicted_class = tf.argmax(prediction, axis=1).numpy()[0]
    return class_names[predicted_class]

# Function to handle the file upload
def handle_upload(encoded_image):
    image_data = base64.b64decode(encoded_image)
    image = preprocess_image(image_data)

    predicted_class = predict_image(image)
    print("Predicted Class:", predicted_class)

# Register the function with Google Colab
from google.colab import output
output.register_callback('handle_upload', handle_upload)

# HTML and JavaScript for the front-end
html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Classifier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        #upload-button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 20px;
        }
        #file-input {
            display: none;
        }
        #image-container {
            margin-top: 20px;
        }
        #image-container img {
            max-width: 100%;
            height: auto;
        }
        #prediction-result {
            font-size: 1.5em;
            margin-top: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Image Classifier</h1>
    <button id="upload-button">Upload Image</button>
    <input type="file" id="file-input" accept="image/*">
    <div id="image-container"></div>
    <div id="prediction-result"></div>

    <script>
        document.getElementById('upload-button').onclick = function() {
            document.getElementById('file-input').click();
        };