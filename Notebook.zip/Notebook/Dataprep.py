import matplotlib.pyplot as plt

# Step 1: Visualize the data before preprocessing
def plot_images_before(images, labels, title, num_images=10):
    plt.figure(figsize=(15, 3))
    for i in range(num_images):
        plt.subplot(1, num_images, i+1)
        plt.xticks([])
        plt.yticks([])
        plt.grid(False)
        plt.imshow(images[i], cmap=plt.cm.binary)
        plt.xlabel(labels[i][0])
    plt.suptitle(title)
    plt.show()

# Step 2: Visualize the data after preprocessing
def plot_images_after(images, title, num_images=10):
    plt.figure(figsize=(15, 3))
    for i in range(num_images):
        plt.subplot(1, num_images, i+1)
        plt.xticks([])
        plt.yticks([])
        plt.grid(False)
        plt.imshow(images[i], cmap=plt.cm.binary)
    plt.suptitle(title)
    plt.show()

# Step 3: Normalize pixel values to be between 0 and 1
train_images_normalized = train_images.astype('float32') / 255.0
test_images_normalized = test_images.astype('float32') / 255.0

# Step 4: Plot images before preprocessing
plot_images_before(train_images, train_labels, title="Original Training Images")

# Step 5: Plot images after preprocessing
plot_images_after(train_images_normalized, title="Normalized Training Images")


# Flatten the images for MLP input
train_images_flattened = train_images_normalized.reshape(train_images_normalized.shape[0], -1)
test_images_flattened = test_images_normalized.reshape(test_images_normalized.shape[0], -1)



# Function to plot flattened images
def plot_flattened_images(flattened_images, original_images, title, num_images=10):
    plt.figure(figsize=(15, 3))
    for i in range(num_images):
        plt.subplot(2, num_images, i+1)
        plt.xticks([])
        plt.yticks([])
        plt.grid(False)
        plt.imshow(original_images[i])
        plt.xlabel("Original")

        plt.subplot(2, num_images, num_images + i + 1)
        plt.xticks([])
        plt.yticks([])
        plt.grid(False)
        plt.plot(flattened_images[i])
        plt.xlabel("Flattened")
    plt.suptitle(title)
    plt.show()



# Plot flattened training images (with comparison to original images)
plot_flattened_images(train_images_flattened, train_images, title="Flattened Training Images")
